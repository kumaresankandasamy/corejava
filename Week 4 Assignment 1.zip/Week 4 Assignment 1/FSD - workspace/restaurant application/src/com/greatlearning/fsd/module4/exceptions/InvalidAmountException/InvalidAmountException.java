package InvalidAmountException;

public class InvalidAmountException {

}
