package com.week4.restaurant.model;

public enum Dishtype {
	Veg,
	Non_Veg

}
