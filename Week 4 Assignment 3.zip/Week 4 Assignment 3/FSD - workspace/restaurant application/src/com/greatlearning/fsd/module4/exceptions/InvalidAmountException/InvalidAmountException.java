package com.greatlearning.fsd.module4.exceptions.InvalidAmountException;

import com.week4.restaurant.controller.Restaurent;

public class InvalidAmountException {

}
